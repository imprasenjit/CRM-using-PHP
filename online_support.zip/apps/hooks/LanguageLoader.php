<?php
class LanguageLoader {
    function initialize() {
        $ci =& get_instance();
        $ci->load->helper("language");
        if($ci->session->userdata("site_lang")) {
            $ci->lang->load("navbar",$ci->session->userdata("site_lang"));
        } else {
            $ci->lang->load("navbar","english");
        }//End of if else
    }//End of initialize()
}//End of LanguageLoader