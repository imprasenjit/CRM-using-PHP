<?php
defined("BASEPATH") OR exit("No direct script access allowed!");
class Leads extends Alom {
    function index() {
        $this->isloggedin();
        $data = array();
        $this->load->model("leads_model");
        if ($this->leads_model->get_rows()) {
            $data["results"] = $this->leads_model->get_rows();
        }//End of if
        $this->load->view("leads_view", $data);
    }//End of index()

    function addnew($id=NULL) {
        $this->isloggedin();
        $data = array();
        $this->load->model("leads_model");
        if ($this->leads_model->get_row($id)) {
            $data["result"] = $this->leads_model->get_row($id);
        }//End of if
        $this->load->view("leadaddnew_view", $data);
    }//End of addnew()
    
    function save() {
        $this->isloggedin();
        $lead_id = $this->input->post("lead_id");
        $this->load->library("form_validation");
        $this->form_validation->set_rules("lead_name", "Name", "required");
        $this->form_validation->set_rules("company_name", "Company", "required");
        $this->form_validation->set_rules("email_id", "Email", "required");
        $this->form_validation->set_rules("contact_no", "Mobile", "required");
        $this->form_validation->set_rules("lead_address", "Address", "required");
        $this->form_validation->set_error_delimiters("<font class='error animated fadeIn'>", "</font>");
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata("flashMsg", "Please check the inputs and try again");
            $this->addnew($lead_id);
        } else {
            $lead_name = $this->input->post("lead_name");
            $company_name = $this->input->post("company_name");
            $email_id = $this->security->xss_clean($this->input->post("email_id"));
            $contact_no = $this->input->post("contact_no");
            $lead_address = $this->input->post("lead_address");
            $source = $this->input->post("source");
            $website = $this->input->post("website");
            $description = $this->input->post("description");
            $data = array(
                "lead_name" => $lead_name,
                "company_name" => $company_name,
                "contact_no" => $contact_no,
                "email_id" => $email_id,
                "lead_address" => $lead_address,
                "source" => $source,
                "website" => $website,
                "description" => $description
            );
            $this->load->model("leads_model");
            if ($lead_id == "") {
                $this->leads_model->add_row($data);
                $msg = "Data has been successfully saved!";
            } else {
                $this->leads_model->edit_row($lead_id, $data);
                $msg = "Data has been successfully updated!";
            }//End of if else
            $this->session->set_flashdata("flashMsg", $msg);
            redirect(site_url("leads"));
        }//End of if else
    }//End of save()

    function delete($id = NULL) {
        $this->isloggedin();
        $this->isadmin();
        $this->load->model("leads_model");
        $this->leads_model->edit_row($id, array("lead_status" => 0));
        $this->session->set_flashdata("flashMsg", "One record has been deleted successfully!");
        redirect(site_url("leads"));
    }// End of delete()
}//End of Leads