<?php
defined("BASEPATH") OR exit("No direct script access allowed!");
class Payments extends Alom {
    function index() {
        $this->isloggedin();
        $data = array();
        $this->load->model("customers_model");
        $this->load->model("payments_model");
        if ($this->payments_model->get_rows()) {
            $data["results"] = $this->payments_model->get_rows();
        }//End of if statement
        $this->load->view("payments_view", $data);
    }//End of index()
    
    function addnew($id=NULL) {
        $this->isloggedin();
        $data = array();
        $this->load->model("payments_model");
        $this->load->model("customers_model");
        if ($this->customers_model->get_rows()) {
            $data["customers"] = $this->customers_model->get_rows();
        }//End of if statement
        if ($this->payments_model->get_row($id)) {
            $data["result"] = $this->payments_model->get_row($id);
        }//End of if
        $this->load->view("paymentaddnew_view", $data);
    }//End of addnew()

    function save() {
        $this->isloggedin();
        $payment_id = $this->input->post("payment_id");
        $this->load->library("form_validation");
        $this->form_validation->set_rules("customer_id", "Customer", "required");
        $this->form_validation->set_rules("payment_mode", "Type", "required");
        $this->form_validation->set_rules("payment_time", "Time", "required");
        $this->form_validation->set_rules("payment_amount", "Title", "required");
        $this->form_validation->set_error_delimiters("<font class='error animated fadeIn'>", "</font>");
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata("flashMsg", "Please check the inputs and try again");
            $this->addnew($payment_id);
        } else {
            $customer_id = $this->input->post("customer_id");
            $payment_mode = $this->input->post("payment_mode");
            $payment_note = $this->security->xss_clean($this->input->post("payment_note"));
            $payment_time = date("Y-m-d H:i:s", strtotime($this->input->post('payment_time')));
            $payment_method = date("Y-m-d", strtotime($this->input->post('payment_method')));
            $payment_amount = $this->input->post("payment_amount");
            $transaction_id = $this->input->post("transaction_id");
            $data = array(
                "customer_id" => $customer_id,
                "payment_mode" => $payment_mode,
                "payment_amount" => $payment_amount,
                "payment_note" => $payment_note,
                "payment_time" => $payment_time,
                "payment_method" => $payment_method,
                "transaction_id" => $transaction_id
            );
            $this->load->model("payments_model");
            if ($payment_id == "") {
                $this->payments_model->add_row($data);
                $msg = "Data has been successfully saved!";
            } else {
                $this->payments_model->edit_row($payment_id, $data);
                $msg = "Data has been successfully updated!";
            }//End of if else
            $this->session->set_flashdata("flashMsg", $msg);
            redirect(site_url("payments"));
        }//End of if else
    }//End of save()
    
    function edit_row() {
        $customer_id = $this->input->post("customer_id");
        $payment_mode = $this->input->post("payment_mode");
        $payment_method = $this->input->post("payment_method");
        $transaction_id = $this->input->post("transaction_id");
        $payment_amount = $this->input->post("payment_amount");
        $data = array(
            "customer_id" => $customer_id,
            "payment_method" => $payment_amount
        );
    }

    function delete($id = NULL) {
        $this->isloggedin();
        $this->isadmin();
        $this->load->model("payments_model");
        $this->payments_model->edit_row($id, array("payment_status" => 0));
        $this->session->set_flashdata("flashMsg", "One record has been deleted successfully!");
        redirect(site_url("payments"));
    }// End of delete()
}//End of Payments