<?php
defined("BASEPATH") OR exit("No direct script access allowed!");
class Customers extends Alom {
    function index() {
        $this->isloggedin();
        $data = array();
        $this->load->model("customers_model");
        if ($this->customers_model->get_rows()) {
            $data["results"] = $this->customers_model->get_rows();
        }
        $this->load->view("customers_view", $data);
    }//End of index()
    
    function addnew($id=NULL) {
        $this->isloggedin("cust_add");
        $data = array();
        $this->load->model("customers_model");
        if ($this->customers_model->get_row($id)) {
            $data["result"] = $this->customers_model->get_row($id);
        }
        $this->load->view("customeraddnew_view", $data);
    }//End of addnew()
    
    function save() {
        $this->isloggedin();
        $customer_id = $this->input->post("customer_id");
        $this->load->library("form_validation");
        $this->form_validation->set_rules("customer_name", "Name", "required");
        $this->form_validation->set_rules("company_name", "Company", "required");
        $this->form_validation->set_rules("email_id", "Email", "required");
        $this->form_validation->set_rules("address", "Address", "required");
        $this->form_validation->set_rules("contact_no", "Mobile", "required");
        $this->form_validation->set_error_delimiters("<font class='error animated fadeIn'>", "</font>");
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata("flashMsg", "Please check the inputs and try again");
            $this->addnew($customer_id);
        } else {
            $customer_name = $this->input->post("customer_name");
            $company_name = $this->input->post("company_name");
            $email_id = $this->security->xss_clean($this->input->post("email_id"));
            $address = $this->input->post("address");
            $contact_no = $this->input->post("contact_no");
            $data = array(
                "customer_name" => $customer_name,
                "company_name" => $company_name,
                "contact_no" => $contact_no,
                "email_id" => $email_id,
                "address" => $address
            );
            $this->load->model("customers_model");
            if ($customer_id == "") {
                $this->customers_model->add_row($data);
                $msg = "Data has been successfully saved!";
            } else {
                $this->isloggedin("cust_edit");
                $this->customers_model->edit_row($customer_id, $data);
                $msg = "Data has been successfully updated!";
            }//End of if else
            $this->session->set_flashdata("flashMsg", $msg);
            redirect(site_url("customers"));
        }//End of if else
    }//End of save()

    function delete($id = NULL) {
        $this->isloggedin();
        $this->isadmin();
        $this->load->model("customers_model");
        $this->customers_model->edit_row($id, array("customer_status" => 0));
        $this->session->set_flashdata("flashMsg", "One record has been deleted successfully!");
        redirect(site_url("customers"));
    }// End of delete()
}//End of Customers