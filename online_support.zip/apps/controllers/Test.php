<?php
defined("BASEPATH") OR exit("No direct script access allowed!");
class Test extends Alom {
    function index() {
        //$this->load->model("settings_model");
        //$assigneduser = $this->settings_model->getdefultusr();
        echo "http : ".(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ?  "https" : "http";
    }//End of index()

    function updatedb() {
        $this->isloggedin();
        //$this->db->query("UPDATE supports SET support_status='5' WHERE support_status='3';");
        $this->db->query("ALTER TABLE calls ADD call_type VARCHAR(255) AFTER call_time");
        //$this->db->query("ALTER TABLE supportprocess ADD process_file VARCHAR(255) AFTER process_msg");
    }//End of updatedb()

   function close($support_id, $rem=NULL) {
        $nowTime = date("Y-m-d H:i:s");
        $this->load->model("supports_model");
        $this->load->model("supportprocess_model");        
        $this->supports_model->edit_row($support_id, array("support_status" => 5));
        if($this->supports_model->get_row($support_id)) {
            $supportRow = $this->supports_model->get_row($support_id);
            $ticket_no = $supportRow->ticket_no;
            $msg =". Ticket (#".$ticket_no.") for EODB supports has been closed manually";
            $pdata = array(
                "support_id" => $support_id,
                "process_time" => $nowTime,
                "processed_by" => $this->session->session_uid,
                "process_msg" => $msg,
                "process_type" => 2
            );
            $this->supportprocess_model->add_row($pdata);
            echo $msg;
        } else {
            echo "ID does not matched!";
        }
    }// End of close()
}//End of Test
