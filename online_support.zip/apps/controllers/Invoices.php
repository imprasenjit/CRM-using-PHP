<?php
defined("BASEPATH") OR exit("No direct script access allowed!");
class Invoices extends Alom {
    function index() {
        $this->isloggedin();
        $data = array();
        $this->load->model("customers_model");
        $this->load->model("invoices_model");
        if ($this->invoices_model->get_rows()) {
            $data["results"] = $this->invoices_model->get_rows();
        }//End of if statement
        $this->load->view("invoices_view", $data);
    }//End of index()
    
    function addnew($id=NULL) {
        $this->isloggedin();
        $data = array();
        $this->load->model("invoices_model");
        $this->load->model("customers_model");
        if ($this->customers_model->get_rows()) {
            $data["customers"] = $this->customers_model->get_rows();
        }//End of if statement
        if ($this->invoices_model->get_row($id)) {
            $data["result"] = $this->invoices_model->get_row($id);
        }//End of if
        $this->load->view("invoiceaddnew_view", $data);
    }//End of addnew()

    function save() {
        $this->isloggedin();
        $invoice_id = $this->input->post("invoice_id");
        $this->load->library("form_validation");
        $this->form_validation->set_rules("customer_id", "Customer", "required");
        $this->form_validation->set_rules("payment_mode", "Type", "required");
        $this->form_validation->set_rules("invoice_time", "Time", "required");
        $this->form_validation->set_rules("invoice_amount", "Title", "required");
        $this->form_validation->set_error_delimiters("<font class='error animated fadeIn'>", "</font>");
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata("flashMsg", "Please check the inputs and try again");
            $this->addnew($invoice_id);
        } else {
            $customer_id = $this->input->post("customer_id");
            $payment_mode = $this->input->post("payment_mode");
            $invoice_note = $this->security->xss_clean($this->input->post("invoice_note"));
            $invoice_time = date("Y-m-d H:i:s", strtotime($this->input->post('invoice_time')));
            $due_date = date("Y-m-d", strtotime($this->input->post('due_date')));
            $invoice_amount = $this->input->post("invoice_amount");
            $invoice_number = $this->input->post("invoice_number");
            $invoice_items = $this->input->post("invoice_items");
            $data = array(
                "customer_id" => $customer_id,
                "payment_mode" => $payment_mode,
                "invoice_amount" => $invoice_amount,
                "invoice_note" => $invoice_note,
                "invoice_time" => $invoice_time,
                "invoice_items" => $invoice_items,
                "invoice_number" => $invoice_number,
                "due_date" => $due_date
            );
            $this->load->model("invoices_model");
            if ($invoice_id == "") {
                $this->invoices_model->add_row($data);
                $msg = "Data has been successfully saved!";
            } else {
                $this->invoices_model->edit_row($invoice_id, $data);
                $msg = "Data has been successfully updated!";
            }//End of if else
            $this->session->set_flashdata("flashMsg", $msg);
            redirect(site_url("invoices"));
        }//End of if else
    }//End of save()
    
    function edit_row() {
        $customer_id = $this->input->post("customer_id");
        $payment_mode = $this->input->post("payment_mode");
        $invoice_items = $this->input->post("invoice_items");
        $invoice_number = $this->input->post("invoice_number");
        $invoice_amount = $this->input->post("invoice_amount");
        $data = array(
            "customer_id" => $customer_id,
            "invoice_items" => $invoice_amount
        );
    }

    function delete($id = NULL) {
        $this->isloggedin();
        $this->isadmin();
        $this->load->model("invoices_model");
        $this->invoices_model->edit_row($id, array("invoice_status" => 0));
        $this->session->set_flashdata("flashMsg", "One record has been deleted successfully!");
        redirect(site_url("invoices"));
    }// End of delete()
}//End of Invoices