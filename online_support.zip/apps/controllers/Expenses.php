<?php
defined("BASEPATH") OR exit("No direct script access allowed!");
class Expenses extends Alom {
    function index() {
        $this->isloggedin();
        $data = array();
        $this->load->model("customers_model");
        $this->load->model("expenses_model");
        if ($this->expenses_model->get_rows()) {
            $data["results"] = $this->expenses_model->get_rows();
        }//End of if statement
        $this->load->view("expenses_view", $data);
    }//End of index()
    
    function addnew($id=NULL) {
        $this->isloggedin();
        $data = array();
        $this->load->model("expenses_model");
        $this->load->model("customers_model");
        if ($this->customers_model->get_rows()) {
            $data["customers"] = $this->customers_model->get_rows();
        }//End of if statement
        if ($this->expenses_model->get_row($id)) {
            $data["result"] = $this->expenses_model->get_row($id);
        }//End of if
        $this->load->view("expenseaddnew_view", $data);
    }//End of addnew()

    function save() {
        $this->isloggedin();
        $expense_id = $this->input->post("expense_id");
        $this->load->library("form_validation");
        $this->form_validation->set_rules("customer_id", "Customer", "required");
        $this->form_validation->set_rules("expense_category", "Category", "required");
        $this->form_validation->set_rules("expense_time", "Time", "required");
        $this->form_validation->set_rules("expense_title", "Title", "required");
        $this->form_validation->set_rules("expense_amount", "Amount", "required");
        $this->form_validation->set_error_delimiters("<font class='error animated fadeIn'>", "</font>");
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata("flashMsg", "Please check the inputs and try again");
            $this->addnew($expense_id);
        } else {
            $customer_id = $this->input->post("customer_id");
            $expense_category = $this->input->post("expense_category");
            $expense_description = $this->security->xss_clean($this->input->post("expense_description"));
            $expense_time = date("Y-m-d H:i:s", strtotime($this->input->post('expense_time')));
            $expense_title = $this->input->post("expense_title");
            $expense_amount = $this->input->post("expense_amount");
            if($_FILES["files"]["name"] !="") {
                $upload_file = $_FILES["files"]["name"];
                $tmp=explode(".", $upload_file);
                $file_extension = strtolower(end($tmp));
                $renameFile=sha1(uniqid(rand())).".".$file_extension;
                $src = "storage/temps/".$upload_file;
                $dst = "storage/uploads/".$renameFile;
                copy($src, $dst);
                unlink($src);
            } else {
                $renameFile = NULL;
            }//End of if else  
            
            $data = array(
                "customer_id" => $customer_id,
                "expense_category" => $expense_category,
                "expense_title" => $expense_title,
                "expense_description" => $expense_description,
                "expense_time" => $expense_time,
                "expense_amount" => $expense_amount,
                "expense_attachment" => $renameFile
            );
            $this->load->model("expenses_model");
            if ($expense_id == "") {
                $this->expenses_model->add_row($data);
                $msg = "Data has been successfully saved!";
            } else {
                $this->expenses_model->edit_row($expense_id, $data);
                $msg = "Data has been successfully updated!";
            }//End of if else
            $this->session->set_flashdata("flashMsg", $msg);
            redirect(site_url("expenses"));
        }//End of if else
    }//End of save()

    function delete($id = NULL) {
        $this->isloggedin();
        $this->isadmin();
        $this->load->model("expenses_model");
        $this->expenses_model->edit_row($id, array("expense_status" => 0));
        $this->session->set_flashdata("flashMsg", "One record has been deleted successfully!");
        redirect(site_url("expenses"));
    }// End of delete()
}//End of Expenses