<?php
defined("BASEPATH") OR exit("No direct script access allowed!");
class Tasks extends Alom {
    function index() {
        $this->isloggedin();
        $data = array();
        $this->load->model("customers_model");
        $this->load->model("tasks_model");
        if ($this->tasks_model->get_rows()) {
            $data["results"] = $this->tasks_model->get_rows();
        }//End of if statement
        $this->load->view("tasks_view", $data);
    }//End of index()
    
    function addnew($id=NULL) {
        $this->isloggedin();
        $data = array();
        $this->load->model("tasks_model");
        $this->load->model("customers_model");
        if ($this->customers_model->get_rows()) {
            $data["customers"] = $this->customers_model->get_rows();
        }//End of if statement
        if ($this->tasks_model->get_row($id)) {
            $data["result"] = $this->tasks_model->get_row($id);
        }//End of if
        $this->load->view("taskaddnew_view", $data);
    }//End of addnew()

    function save() {
        $this->isloggedin();
        $task_id = $this->input->post("task_id");
        $this->load->library("form_validation");
        $this->form_validation->set_rules("customer_id", "Customer", "required");
        $this->form_validation->set_rules("task_type", "Type", "required");
        $this->form_validation->set_rules("task_time", "Time", "required");
        $this->form_validation->set_rules("task_title", "Title", "required");
        $this->form_validation->set_error_delimiters("<font class='error animated fadeIn'>", "</font>");
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata("flashMsg", "Please check the inputs and try again");
            $this->addnew($task_id);
        } else {
            $customer_id = $this->input->post("customer_id");
            $task_type = $this->input->post("task_type");
            $task_description = $this->security->xss_clean($this->input->post("task_description"));
            $task_time = date("Y-m-d H:i:s", strtotime($this->input->post('task_time')));
            $due_date = date("Y-m-d", strtotime($this->input->post('due_date')));
            $task_title = $this->input->post("task_title");
            $assign_to = $this->input->post("assign_to");
            $data = array(
                "customer_id" => $customer_id,
                "task_type" => $task_type,
                "task_title" => $task_title,
                "task_description" => $task_description,
                "task_time" => $task_time,
                "due_date" => $due_date,
                "assign_to" => $assign_to
            );
            $this->load->model("tasks_model");
            if ($task_id == "") {
                $this->tasks_model->add_row($data);
                $msg = "Data has been successfully saved!";
            } else {
                $this->tasks_model->edit_row($task_id, $data);
                $msg = "Data has been successfully updated!";
            }//End of if else
            $this->session->set_flashdata("flashMsg", $msg);
            redirect(site_url("tasks"));
        }//End of if else
    }//End of save()

    function delete($id = NULL) {
        $this->isloggedin();
        $this->isadmin();
        $this->load->model("tasks_model");
        $this->tasks_model->edit_row($id, array("task_status" => 0));
        $this->session->set_flashdata("flashMsg", "One record has been deleted successfully!");
        redirect(site_url("tasks"));
    }// End of delete()
}//End of Tasks