<?php
defined("BASEPATH") OR exit("No direct script access allowed!");
class Projects extends Alom {
    function index() {
        $this->isloggedin();
        $data = array();
        $this->load->model("projects_model");
        if ($this->projects_model->get_rows()) {
            $data["results"] = $this->projects_model->get_rows();
        }
        $this->load->view("projects_view", $data);
    }//End of index()
    
    function addnew($id=NULL) {
        $this->isloggedin();
        $data = array();
        $this->load->model("projects_model");
        if ($this->projects_model->get_row($id)) {
            $data["result"] = $this->projects_model->get_row($id);
        }
        $this->load->view("projectaddnew_view", $data);
    }//End of addnew()
    
    function save() {
        $this->isloggedin();
        $project_id = $this->input->post("project_id");
        $this->load->library("form_validation");
        $this->form_validation->set_rules("project_name", "Name", "required");
        $this->form_validation->set_rules("company_name", "Company", "required");
        $this->form_validation->set_rules("email_id", "Email", "required");
        $this->form_validation->set_rules("address", "Address", "required");
        $this->form_validation->set_rules("contact_no", "Mobile", "required");
        $this->form_validation->set_error_delimiters("<font class='error animated fadeIn'>", "</font>");
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata("flashMsg", "Please check the inputs and try again");
            $this->addnew($project_id);
        } else {
            $project_name = $this->input->post("project_name");
            $company_name = $this->input->post("company_name");
            $project_description = $this->input->post("project_description");
            $email_id = $this->security->xss_clean($this->input->post("email_id"));
            $address = $this->input->post("address");
            $contact_no = $this->input->post("contact_no");
            $data = array(
                "project_name" => $project_name,
                "company_name" => $company_name,
                "project_description" => $project_description,
                "contact_no" => $contact_no,
                "email_id" => $email_id,
                "address" => $address
            );
            $this->load->model("projects_model");
            if ($project_id == "") {
                $this->projects_model->add_row($data);
                $msg = "Data has been successfully saved!";
            } else {
                $this->projects_model->edit_row($project_id, $data);
                $msg = "Data has been successfully updated!";
            }//End of if else
            $this->session->set_flashdata("flashMsg", $msg);
            redirect(site_url("projects"));
        }//End of if else
    }//End of save()

    function delete($id = NULL) {
        $this->isloggedin();
        $this->isadmin();
        $this->load->model("projects_model");
        $this->projects_model->edit_row($id, array("project_status" => 0));
        $this->session->set_flashdata("flashMsg", "One record has been deleted successfully!");
        redirect(site_url("projects"));
    }// End of delete()
}//End of Projects