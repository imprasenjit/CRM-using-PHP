<?php
defined("BASEPATH") OR exit("No direct script access allowed!");
class Comments extends Alom {
    function index() {
        $this->isloggedin();
        $data = array();
        $this->load->model("customers_model");
        if ($this->customers_model->get_rows()) {
            $data["results"] = $this->customers_model->get_rows();
        }
        $this->load->view("customers_view", $data);
    }//End of index()
    
    function save() {
        $this->isloggedin();
        $nowTime = date("Y-m-d H:i:s");
        $support_id = $this->input->post("support_id");
        $this->load->library("form_validation");
        $this->form_validation->set_rules("comment", "Name", "required");
        $this->form_validation->set_error_delimiters("<font class='error animated fadeIn'>", "</font>");
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata("flashMsg", "Comment cannot be empty!");
        } else {
            $comment = $this->input->post("comment");
            $pdata = array(
                "support_id" => $support_id,
                "process_time" => $nowTime,
                "processed_by" => $this->session->session_uid,
                "process_type" => 4,
                "process_msg" => $comment
            );
            $this->load->model("supportprocess_model");
            $this->supportprocess_model->add_row($pdata);
            $this->session->set_flashdata("flashMsg", "Data has been successfully updated!");            
        }//End of if else
        redirect(site_url("supports/details/".$support_id));
    }//End of save()
}//End of Comments