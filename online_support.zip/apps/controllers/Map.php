<?php
defined("BASEPATH") OR exit("No direct script access allowed!");
class Map extends Alom {
    function index() {
        $this->load->view("map_view");
    }//End of index()
}//End of Map
