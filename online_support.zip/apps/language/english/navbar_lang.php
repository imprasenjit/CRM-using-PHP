<?php
$ci =& get_instance();
$ci->load->model("admin/menus_model");
foreach($ci->menus_model->get_rows() as $rows) {
    $menu_name = $rows->menu_name;
    $menu_english = $rows->menu_english;
    $lang[$menu_name] = $menu_english;
}//End of foreach()

$ci->load->model("admin/navbars_model");
foreach($ci->navbars_model->get_rows() as $rows) {
    $navbar_name = $rows->navbar_name;
    $navbar_english = $rows->navbar_english;
    $lang[$navbar_name] = $navbar_english;
}//End of foreach()

$lang["brekingnews"] = "BREAKING NEWS";