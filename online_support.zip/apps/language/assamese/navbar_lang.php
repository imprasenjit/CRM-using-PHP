<?php
$ci =& get_instance();
$ci->load->model("admin/menus_model");
foreach($ci->menus_model->get_rows() as $rows) {
    $menu_name = $rows->menu_name;
    $menu = $rows->menu_assamese;
    $lang[$menu_name] = $menu;
}//End of foreach()

$ci->load->model("admin/navbars_model");
foreach($ci->navbars_model->get_rows() as $rows) {
    $navbar_name = $rows->navbar_name;
    $navbar = $rows->navbar_assamese;
    $lang[$navbar_name] = $navbar;
}//End of foreach()

$lang["brekingnews"] = "সদ্যপ্রাপ্ত সংবাদ";