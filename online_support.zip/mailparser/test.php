<?php
	echo __DIR__.'/attachments/';die();
// Include the library first
include 'src/Parser.php';
$path = 'email.txt';
$Parser = new PhpMimeMailParser\Parser();

// There are four methods available to indicate which mime mail to parse.
// You only need to use one of the following four:

// 1. Specify a file path to the mime mail.
$Parser->setPath($path); 

// 2. Specify a php file resource (stream) to the mime mail.
//$Parser->setStream(fopen($path, "r"));

// 3. Specify the raw mime mail text.
//$Parser->setText(file_get_contents($path));

// 4.  Specify a stream to work with mail server
//$Parser->setStream(fopen("php://stdin", "r"));

// Once we've indicated where to find the mail, we can parse out the data
$to = $Parser->getHeader('to');             // "test" <test@example.com>, "test2" <test2@example.com>
$addressesTo = $Parser->getAddresses('to'); //Return an array : [["display"=>"test", "address"=>"test@example.com", false],["display"=>"test2", "address"=>"test2@example.com", false]]

$from = $Parser->getHeader('from');             // "test" <test@example.com>

$addressesFrom = $Parser->getAddresses('from'); //Return an array : [["display"=>"test", "address"=>"test@example.com", "is_group"=>false]]

$subject = $Parser->getHeader('subject');

$text = $Parser->getMessageBody('text');
$lines = explode(PHP_EOL, trim($text));
$newstr="";
foreach($lines as $line){
	$newstr.=$line."<br><br>";
}

echo '<hr>TEXT<hr>'.$newstr;
$html = $Parser->getMessageBody('html');

//echo '<hr>HTML<hr>'.$html;
$htmlEmbedded = $Parser->getMessageBody('htmlEmbedded'); //HTML Body included data

//echo '<hr>htmlEmbedded</hr>'.$htmlEmbedded;

$stringHeaders = $Parser->getHeadersRaw();	// Get all headers as a string, no charset conversion
$arrayHeaders = $Parser->getHeaders();		// Get all headers as an array, with charset conversion

// Pass in a writeable path to save attachments
$attach_dir = '/path/to/save/attachments/'; 	// Be sure to include the trailing slash
$include_inline = true;  			// Optional argument to include inline attachments (default: true)
$Parser->saveAttachments($attach_dir ,$include_inline);

// Get an array of Attachment items from $Parser
$attachments = $Parser->getAttachments([$include_inline]);

//  Loop through all the Attachments
if (count($attachments) > 0) {
	foreach ($attachments as $attachment) {
		echo 'Filename : '.$attachment->getFilename().'<br />'; // logo.jpg
		echo 'Filesize : '.filesize($attach_dir.$attachment->getFilename()).'<br />'; // 1000
		echo 'Filetype : '.$attachment->getContentType().'<br />'; // image/jpeg
		echo 'MIME part string : '.$attachment->getMimePartStr().'<br />'; // (the whole MIME part of the attachment)
	}
}

?>