<?php

namespace PhpMimeMailParser;

class Exception extends \RuntimeException
{

}
