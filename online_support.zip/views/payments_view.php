<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Payments - Avantika CRM</title>      
        <?php $this->load->view('requires/cssjs'); ?>
        <link rel="stylesheet" href="<?=base_url('public/datatables/css/dataTables.bootstrap4.min.css')?>" />
        <script src="<?=base_url('public/datatables/js/jquery.dataTables.min.js')?>"></script>
        <script src="<?=base_url('public/datatables/js/dataTables.bootstrap4.min.js')?>"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $("#dtbl").DataTable({
                    "order": [[0, 'asc']],
                    "lengthMenu": [[10, 20, 50, 100, 200], [10, 20, 50, 100, 200]]
                });
            });
        </script>
    </head>
    <body class="fixed-nav sticky-footer bg-dark" id="page-top">
        <?php if ($this->session->flashdata("flashMsg")) { ?>
            <script type="text/javascript">
                $.notify("<?=$this->session->flashdata("flashMsg")?>", "success");
            </script>
        <?php } ?>
        <?php $this->load->view('requires/navbar'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">
                <ol class="breadcrumb" style="padding: .5rem; margin-bottom: 1rem">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url('welcome')?>">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">Payments</li>
                    <li style="float: right">
                        <a href="javascript:history.back(-1)" class="btn btn-info" style="margin: 0px; padding: 4px;">
                            <i class="fa fa-chevron-circle-left"></i> Back
                        </a>
                    </li>
                </ol><!-- End of .breadcrumb-item-->
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card tblcard border-secondary">
                            <div class="card-header">
                                <i class="fa fa-list-alt"></i> Registered payments list
                                <a href="<?=base_url('payments/addnew')?>" class="btn btn-primary" style="margin: 0px; padding: 4px; float: right">
                                    <i class="fa fa-plus-circle"></i> Add new payment
                                </a>
                            </div>
                            <div class="card-body card-body-padding table-responsive" style="padding: 1px">
                                <table class="table table-bordered table-responsive" id="dtbl">
                                    <thead>
                                        <tr>
                                            <th>Transaction ID</th>
                                            <th>Payment Time</th>
                                            <th>Customer</th>
                                            <th>Pay Mode</th>
                                            <th>Pay Amount</th>
                                            <th class="text-center">Operations</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if(isset($results)) {
                                            foreach ($results as $rows) {
                                                $payment_id = $rows->payment_id;
                                                $transaction_id = $rows->transaction_id;
                                                $customer_id = $rows->customer_id;
                                                $cname = ($this->customers_model->get_row($customer_id))?$this->customers_model->get_row($customer_id)->customer_name:"Not found!";
                                                $payment_mode = $rows->payment_mode;
                                                if($payment_mode == 1) {
                                                    $qType = "Online";
                                                } elseif($payment_mode == 2) {
                                                    $qType = "Cash";
                                                } elseif($payment_mode == 3) {
                                                    $qType = "Cheque";
                                                } else {
                                                    $qType = "Not found!";
                                                }//End of if else
                                                $payment_amount  = $rows->payment_amount;
                                                $payment_note = $rows->payment_note;
                                                $payment_time = date("d-m-Y h:i A", strtotime($rows->payment_time));
                                                ?>
                                                <tr>
                                                    <td><?=$transaction_id?></td>
                                                    <td><?=$payment_time?></td>
                                                    <td><?=$cname?></td>
                                                    <td><?=$qType?></td>
                                                    <td><i class="fa fa-inr"></i> <?=sprintf("%0.2f", $payment_amount)?></td>
                                                    <td class="text-center">
                                                        <a href="<?=base_url('payments/delete/')?><?=$payment_id?>.htm" class="btn btn-danger del">
                                                            <i class="fa fa-remove"></i>
                                                        </a>
                                                        <a href="<?=base_url('payments/addnew/')?><?=$payment_id?>.htm" class="btn btn-primary">
                                                            <i class="fa fa-pencil"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php                     
                                            }// End of foreach
                                        }// End of if  
                                        ?>                           
                                    </tbody>
                                </table>
                            </div><!--End of card-body-->
                        </div><!--End of .card-->
                    </div>
                </div><!--End of .row-->
            </div><!--End of container-fluid-->
            <?php $this->load->view('requires/footer'); ?>
            <?php $this->load->view('requires/logoutmodal'); ?>
        </div>
    </body>
</html>