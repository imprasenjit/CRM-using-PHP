<?php
if (isset($result)) {
    $title = "Edit Task Information";
    $task_id = $result->task_id;
    $customer_id = $result->customer_id;
    $customer_name = $this->customers_model->get_row($customer_id)->customer_name;
    $task_type = $result->task_type;
    if($task_type == 1) {
        $qType = "Low";
    } elseif($task_type == 2) {
        $qType = "Medium";
    } elseif($task_type == 3) {
        $qType = "High";
    } else {
        $qType = "Select";
    }//End of if else
    $task_title = $result->task_title;
    $task_description = $result->task_description;
    $task_time = $result->task_time;
    $due_date = $result->due_date;
    $assign_to = $result->assign_to;
} else {
    $title = "New Task Registration";
    $task_id = "";
    $customer_id = set_value("customer_id");
    $customer_name = ($this->customers_model->get_row($customer_id))?$this->customers_model->get_row($customer_id)->customer_name:"Select";
    $task_type = set_value("task_type");
    if($task_type == 1) {
        $qType = "Low";
    } elseif($task_type == 2) {
        $qType = "Medium";
    } elseif($task_type == 3) {
        $qType = "High";
    } else {
        $qType = "Select";
    }//End of if else
    $task_title = set_value("task_title");
    $task_description = set_value("task_description");
    $task_time = date("d-m-Y H:i:s");
    $due_date = set_value("due_date");
    $assign_to = set_value("assign_to");
}//End of if else
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Tasks - Avantika CRM</title>      
        <?php $this->load->view('requires/cssjs'); ?>
        <link href="<?=base_url('public/jquery-ui-1.12.1/jquery-ui.min.css')?>" rel="stylesheet" type="text/css" />
        <script src="<?=base_url('public/jquery-ui-1.12.1/jquery-ui.min.js')?>"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $(".dp").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    maxDate: "0m -1d",
                    dateFormat: "dd-mm-yy"
                }); //End of onclick .datepicker
                
                $(".dpnxt").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    minDate: "1m 1d",
                    dateFormat: "dd-mm-yy"
                }); //End of onclick .datepicker
            });
        </script>
    </head>
    <body class="fixed-nav sticky-footer bg-dark" id="page-top">
        <?php if ($this->session->flashdata("flashMsg")) { ?>
            <script type="text/javascript">
                $.notify("<?=$this->session->flashdata("flashMsg")?>", "success");
            </script>
        <?php } ?>
        <?php $this->load->view('requires/navbar'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">
                <ol class="breadcrumb" style="padding: .5rem; margin-bottom: 1rem">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url('')?>">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">Tasks</li>
                </ol><!-- End of .breadcrumb-item-->
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card frmcard border-primary">
                            <form action="<?=base_url('tasks/save')?>" method="post">
                                <div class="card-header">
                                    <i class="fa fa-university"></i> <?=$title?>
                                </div>
                                <div class="card-body">
                                    <input type="hidden" name="task_id" id="task_id" value="<?=$task_id?>" />
                                    <div class="row">
                                        <div class=" col-md-6 form-group">
                                            <label>Customer<span class="text-danger">*</span></label>
                                            <select name="customer_id" class="form-control">
                                                <option value="<?=$customer_id?>" selected="selected"><?=$customer_name?></option>
                                                <?php 
                                                if(isset($customers)) {
                                                    foreach($customers as $custs) { ?>
                                                    <option value="<?=$custs->customer_id?>" >
                                                        <?=$custs->customer_name?>
                                                    </option>
                                                    <?php } //End of foreach  ?>
                                                <?php } else {
                                                    echo "<option value=''>No records found</option>";
                                                } //End of if else ?>
                                            </select>
                                            <?=form_error("customer_id")?>
                                        </div>

                                        <div class="col-md-6 form-group">
                                            <label>Priority<span class="text-danger">*</span></label>
                                            <select name="task_type" id="noq" class="form-control">
                                                <option value="<?=$task_type?>" selected="selected"><?=$qType?></option>
                                                <option value="1">Low</option>
                                                <option value="2">Medium</option>
                                                <option value="3">High</option>
                                            </select>
                                            <?=form_error("task_type")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                    <div class="row">
                                        <div class="col-md-12 form-group">
                                            <label>Task<span class="text-danger">*</span></label>
                                            <textarea name="task_title" class="form-control"><?=$task_title?></textarea>
                                            <?=form_error("task_title")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                    <div class="row">
                                        <div class="col-md-12 form-group">
                                            <label>Description</label>
                                            <textarea name="task_description" class="form-control"><?=$task_description?></textarea>
                                            <?=form_error("task_description")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label>Start Time<span class="text-danger">*</span></label>
                                            <input type="text" name="task_time" value="<?=$task_time?>" class="form-control dp" />
                                            <?=form_error("task_time")?>
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>Due date<span class="text-danger">*</span></label>
                                            <input type="text" name="due_date" value="<?=$due_date?>" class="form-control dpnxt" />
                                            <?=form_error("due_date")?>
                                        </div>
                                    </div> <!-- End of .row -->
                                    
                                    <div class="row">
                                        <div class="col-md-12 form-group">
                                            <label>Assign to<span class="text-danger">*</span></label>
                                            <input type="text" name="assign_to" value="<?=$assign_to?>" class="form-control" />
                                            <?=form_error("assign_to")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                </div><!--End of .card-body-->
                                
                                <div class="card-footer text-center">
                                    <button type="reset" class="btn btn-danger">
                                        <i class="fa fa-remove"></i> Reset
                                    </button>
                                    <button type="submit" class="btn btn-success">
                                        <i class="fa fa-check"></i> Save
                                    </button>
                                </div><!--End of .card-footer-->
                            </form>
                        </div><!--End of .card-->
                    </div><!--End of .col-md-12-->
                </div><!--End of .row-->
            </div><!--End of container-fluid-->
            <?php $this->load->view('requires/footer'); ?>
            <?php $this->load->view('requires/logoutmodal'); ?>
        </div><!--End of content-wrapper-->
    </body>
</html>