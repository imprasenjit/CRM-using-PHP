<nav class="navbar navbar-light bg-light static-top">
    <div class="container">
        <a class="navbar-brand" href="<?= base_url('home') ?>">
            <i class="fa fa-handshake-o"></i> EODB SUPPORTS
        </a>
        <a class="btn btn-warning" href="<?= base_url('welcome') ?>">
            <i class="fa fa-user-secret"></i> STAFF LOGIN
        </a>
    </div>
</nav>