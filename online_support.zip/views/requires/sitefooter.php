<!--<footer class="footer" style="background: #ddd">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 h-100 text-center text-lg-left my-auto">
                <ul class="list-inline mb-2">
                    <li class="list-inline-item">
                        <a href="https://easeofdoingbusinessinassam.in/#secondPage" target="_blank">About us</a>
                    </li>
                    <li class="list-inline-item">&sdot;</li>
                    <li class="list-inline-item">
                        <a href="https://easeofdoingbusinessinassam.in/#5thpage" target="_blank">Contact us</a>
                    </li>
                    <li class="list-inline-item">&sdot;</li>
                    <li class="list-inline-item">
                        <a href="https://easeofdoingbusinessinassam.in/homepage/terms.php" target="_blank">Terms &amp; conditions</a>
                    </li>
                    <li class="list-inline-item">&sdot;</li>
                    <li class="list-inline-item">
                        <a href="https://easeofdoingbusinessinassam.in/homepage/privacy.php" target="_blank">Privacy Policy</a>
                    </li>
                </ul>
                <p class="text-muted small mb-4 mb-lg-0">&copy;2018 EODB Supports. All Rights Reserved.</p>
            </div>
            <div class="col-lg-6 h-100 text-center text-lg-right my-auto">
                <ul class="list-inline mb-0">
                    <li class="list-inline-item mr-3">
                        <a href="https://www.youtube.com/channel/UCrDhBN9tvYzIrEfCWdmRlYQ" target="_blank">
                            <i class="fa fa-youtube fa-2x fa-fw"></i>
                        </a>
                    </li>
                    <li class="list-inline-item mr-3">
                        <a href="https://www.facebook.com/" target="_blank">
                            <i class="fa fa-facebook fa-2x fa-fw"></i>
                        </a>
                    </li>
                    <li class="list-inline-item mr-3">
                        <a href="https://twitter.com/" target="_blank">
                            <i class="fa fa-twitter fa-2x fa-fw"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://plus.google.com/" target="_blank">
                            <i class="fa fa-google-plus fa-2x fa-fw"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>-->