<footer class="sticky-footer">
    <div class="container">
        <div class="text-center">
            <small>Copyright © CRM 2018</small>
        </div>
    </div>
</footer>
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fa fa-angle-up"></i>
</a>
