<?php
if (isset($result)) {
    $title = "Edit Lead Information";
    $lead_id = $result->lead_id;
    $lead_name = $result->lead_name;
    $company_name = $result->company_name;
    $contact_no = $result->contact_no;
    $email_id = $result->email_id;
    $website = $result->website;
    $source = $result->source;
    $lead_address = $result->lead_address;
    $description = $result->description;
} else {
    $title = "New Lead Registration";
    $lead_id = "";
    $lead_name = set_value("lead_name");
    $company_name = set_value("company_name");
    $contact_no = set_value("contact_no");
    $email_id = set_value("email_id");
    $website = set_value("website");
    $source = set_value("source");
    $lead_address = set_value("lead_address");
    $description = set_value("description");
} ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Leads - Avantika CRM</title>      
        <?php $this->load->view('requires/cssjs'); ?>
    </head>
    <body class="fixed-nav sticky-footer bg-dark" id="page-top">
        <?php if ($this->session->flashdata("flashMsg")) { ?>
            <script type="text/javascript">
                $.notify("<?=$this->session->flashdata("flashMsg")?>", "success");
            </script>
        <?php } ?>
        <?php $this->load->view('requires/navbar'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">
                <ol class="breadcrumb" style="padding: .5rem; margin-bottom: 1rem">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url('')?>">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">Leads</li>
                    <li style="float: right">
                        <a href="javascript:history.back(-1)" class="btn btn-info" style="margin: 0px; padding: 4px;">
                            <i class="fa fa-chevron-circle-left"></i> Back
                        </a>
                    </li>
                </ol><!-- End of .breadcrumb-item-->
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card frmcard border-primary">
                            <form action="<?=base_url('leads/save')?>" method="post">
                                <div class="card-header">
                                    <i class="fa fa-university"></i> <?=$title?>
                                </div>
                                <div class="card-body">
                                    <input type="hidden" name="lead_id" id="lead_id" value="<?=$lead_id?>" />
                                    <div class="row">
                                        <div class=" col-md-6 form-group">
                                            <label>Lead Name<span class="text-danger">*</span></label>
                                            <input type="text" name="lead_name" value="<?=$lead_name?>" class="form-control" autocomplete="off" />
                                            <?=form_error("lead_name")?>
                                        </div>

                                        <div class="col-md-6 form-group">
                                            <label>Company<span class="text-danger">*</span></label>
                                            <input type="text" name="company_name" value="<?=$company_name?>" class="form-control" />
                                            <?=form_error("company_name")?>
                                        </div>
                                    </div> <!-- End of .row -->                                    
                                    
                                    <div class="row">
                                        <div class=" col-md-6 form-group">
                                            <label>Website<span class="text-danger">*</span></label>
                                            <input type="text" name="website" value="<?=$website?>" class="form-control" autocomplete="off" />
                                            <?=form_error("website")?>
                                        </div>

                                        <div class="col-md-6 form-group">
                                            <label>Source<span class="text-danger">*</span></label>
                                            <input type="text" name="source" value="<?=$source?>" class="form-control" />
                                            <?=form_error("source")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label>Contact No.<span class="text-danger">*</span></label>
                                            <input type="text" name="contact_no" value="<?=$contact_no?>" class="form-control" maxlength="10" />
                                            <?=form_error("contact_no")?>
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>Email ID<span class="text-danger">*</span></label>
                                            <input type="text" name="email_id" value="<?=$email_id?>" class="form-control" />
                                            <?=form_error("email_id")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                    <div class="row">
                                        <div class="col-md-12 form-group">
                                            <label>Address<span class="text-danger">*</span></label>
                                            <textarea name="lead_address" class="form-control"><?=$lead_address?></textarea>
                                            <?=form_error("lead_address")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                    <div class="row">
                                        <div class="col-md-12 form-group">
                                            <label>Description<span class="text-danger">*</span></label>
                                            <textarea name="description" class="form-control"><?=$description?></textarea>
                                            <?=form_error("description")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                </div><!--End of .card-body-->
                                
                                <div class="card-footer text-center">
                                    <button type="reset" class="btn btn-danger">
                                        <i class="fa fa-remove"></i> Reset
                                    </button>
                                    <button type="submit" class="btn btn-success">
                                        <i class="fa fa-check"></i> Save
                                    </button>
                                </div><!--End of .card-footer-->
                            </form>
                        </div><!--End of .card-->
                    </div><!--End of .col-md-12-->
                </div><!--End of .row-->
            </div><!--End of container-fluid-->
            <?php $this->load->view('requires/footer'); ?>
            <?php $this->load->view('requires/logoutmodal'); ?>
        </div>
    </body>
</html>