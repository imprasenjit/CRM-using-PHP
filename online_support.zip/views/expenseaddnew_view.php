<?php
if (isset($result)) {
    $title = "Edit Expense Information";
    $expense_id = $result->expense_id;
    $customer_id = $result->customer_id;
    $customer_name = $this->customers_model->get_row($customer_id)->customer_name;
    $expense_category = $result->expense_category;
    if($expense_category == 1) {
        $qType = "Low";
    } elseif($expense_category == 2) {
        $qType = "Medium";
    } elseif($expense_category == 3) {
        $qType = "High";
    } else {
        $qType = "Select";
    }//End of if else
    $expense_title = $result->expense_title;
    $expense_amount = $result->expense_amount;
    $expense_description = $result->expense_description;
    $expense_time = $result->expense_time;
} else {
    $title = "New Expense Registration";
    $expense_id = "";
    $customer_id = set_value("customer_id");
    $customer_name = ($this->customers_model->get_row($customer_id))?$this->customers_model->get_row($customer_id)->customer_name:"Select";
    $expense_category = set_value("expense_category");
    if($expense_category == 1) {
        $qType = "CAF";
    } elseif($expense_category == 2) {
        $qType = "Dashboard";
    } elseif($expense_category == 3) {
        $qType = "Departmental";
    } else {
        $qType = "Select";
    }//End of if else
    $expense_title = set_value("expense_title");
    $expense_description = set_value("expense_description");
    $expense_time = date("d-m-Y H:i:s");
    $expense_amount = set_value("expense_amount");
}//End of if else
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Expenses - EODB Support</title>      
        <?php $this->load->view('requires/cssjs'); ?>
        <link href="<?=base_url('public/jquery-ui-1.12.1/jquery-ui.min.css')?>" rel="stylesheet" type="text/css" />
        <script src="<?=base_url('public/jquery-ui-1.12.1/jquery-ui.min.js')?>"></script>
        <script src="<?=base_url('public/pekeupload/js/pekeUpload.js')?>"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $(".dp").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    maxDate: "0m -1d",
                    dateFormat: "dd-mm-yy"
                }); //End of onclick .datepicker
                                
                $("#files").pekeUpload({
                    bootstrap: true,
                    limit: 1,
                    maxSize: 2,
                    url: "<?=base_url('public/pekeupload/upload.php')?>"
                });
            });
        </script>
    </head>
    <body class="fixed-nav sticky-footer bg-dark" id="page-top">
        <?php if ($this->session->flashdata("flashMsg")) { ?>
            <script type="text/javascript">
                $.notify("<?=$this->session->flashdata("flashMsg")?>", "success");
            </script>
        <?php } ?>
        <?php $this->load->view('requires/navbar'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">
                <ol class="breadcrumb" style="padding: .5rem; margin-bottom: 1rem">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url('')?>">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">Expenses</li>
                    <li style="float: right">
                        <a href="javascript:history.back(-1)" class="btn btn-info" style="margin: 0px; padding: 4px;">
                            <i class="fa fa-chevron-circle-left"></i> Back
                        </a>
                    </li>
                </ol><!-- End of .breadcrumb-item-->
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card frmcard border-primary">
                            <form action="<?=base_url('expenses/save')?>" method="post" enctype="multipart/form-data">
                                <div class="card-header">
                                    <i class="fa fa-university"></i> <?=$title?>
                                </div>
                                <div class="card-body">
                                    <input type="hidden" name="expense_id" id="expense_id" value="<?=$expense_id?>" />
                                    <div class="row">
                                        <div class=" col-md-6 form-group">
                                            <label>Customer<span class="text-danger">*</span></label>
                                            <select name="customer_id" class="form-control">
                                                <option value="<?=$customer_id?>" selected="selected"><?=$customer_name?></option>
                                                <?php 
                                                if(isset($customers)) {
                                                    foreach($customers as $custs) { ?>
                                                    <option value="<?=$custs->customer_id?>" >
                                                        <?=$custs->customer_name?>
                                                    </option>
                                                    <?php } //End of foreach  ?>
                                                <?php } else {
                                                    echo "<option value=''>No records found</option>";
                                                } //End of if else ?>
                                            </select>
                                            <?=form_error("customer_id")?>
                                        </div>

                                        <div class="col-md-6 form-group">
                                            <label>Category<span class="text-danger">*</span></label>
                                            <select name="expense_category" id="noq" class="form-control">
                                                <option value="<?=$expense_category?>" selected="selected"><?=$qType?></option>
                                                <option value="1">Low</option>
                                                <option value="2">Medium</option>
                                                <option value="3">High</option>
                                            </select>
                                            <?=form_error("expense_category")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                    <div class="row">
                                        <div class="col-md-12 form-group">
                                            <label>Expense Title<span class="text-danger">*</span></label>
                                            <textarea name="expense_title" class="form-control"><?=$expense_title?></textarea>
                                            <?=form_error("expense_title")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                    <div class="row">
                                        <div class="col-md-12 form-group">
                                            <label>Description</label>
                                            <textarea name="expense_description" class="form-control"><?=$expense_description?></textarea>
                                            <?=form_error("expense_description")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label>Expense Time<span class="text-danger">*</span></label>
                                            <input type="text" name="expense_time" value="<?=$expense_time?>" class="form-control dp" />
                                            <?=form_error("expense_time")?>
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>Expense Amount<span class="text-danger">*</span></label><br />
                                            <input type="text" name="expense_amount" value="<?=$expense_amount?>" class="form-control" />
                                            <?=form_error("expense_amount")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                    <div class="row">
                                        <div class="col-md-12 form-group">
                                            <label>Attachment<span class="text-danger">*</span></label><br />
                                            <input type="file" name="files" id="files" />
                                        </div>
                                    </div> <!-- End of .row -->

                                </div><!--End of .card-body-->
                                
                                <div class="card-footer text-center">
                                    <button type="reset" class="btn btn-danger">
                                        <i class="fa fa-remove"></i> Reset
                                    </button>
                                    <button type="submit" class="btn btn-success">
                                        <i class="fa fa-check"></i> Save
                                    </button>
                                </div><!--End of .card-footer-->
                            </form>
                        </div><!--End of .card-->
                    </div><!--End of .col-md-12-->
                </div><!--End of .row-->
            </div><!--End of container-fluid-->
            <?php $this->load->view('requires/footer'); ?>
            <?php $this->load->view('requires/logoutmodal'); ?>
        </div>
    </body>
</html>