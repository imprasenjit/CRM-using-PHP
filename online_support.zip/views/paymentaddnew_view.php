<?php
if (isset($result)) {
    $title = "Edit Payment Information";
    $payment_id = $result->payment_id;
    $customer_id = $result->customer_id;
    $customer_name = $this->customers_model->get_row($customer_id)->customer_name;
    $payment_mode = $result->payment_mode;
    if($payment_mode == 1) {
        $pMode = "Online";
    } elseif($payment_mode == 2) {
        $pMode = "Cash";
    } elseif($payment_mode == 3) {
        $pMode = "Cheque";
    } else {
        $pMode = "Select";
    }//End of if else
    $payment_amount = $result->payment_amount;
    $payment_note = $result->payment_note;
    $payment_time = $result->payment_time;
    $payment_method = $result->payment_method;
    $transaction_id = $result->transaction_id;
} else {
    $title = "New Payment Entry";
    $payment_id = "";
    $customer_id = set_value("customer_id");
    $customer_name = ($this->customers_model->get_row($customer_id))?$this->customers_model->get_row($customer_id)->customer_name:"Select";
    $payment_mode = set_value("payment_mode");
    if($payment_mode == 1) {
        $pMode = "Online";
    } elseif($payment_mode == 2) {
        $pMode = "Cash";
    } elseif($payment_mode == 3) {
        $pMode = "Cheque";
    } else {
        $pMode = "Select";
    }//End of if else
    $payment_amount = set_value("payment_amount");
    $payment_note = set_value("payment_note");
    $payment_time = date("d-m-Y H:i:s");
    $payment_method = set_value("payment_method");
    $transaction_id = set_value("transaction_id");
}//End of if else
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Payments - Avantika CRM</title>      
        <?php $this->load->view('requires/cssjs'); ?>
        <link href="<?=base_url('public/jquery-ui-1.12.1/jquery-ui.min.css')?>" rel="stylesheet" type="text/css" />
        <script src="<?=base_url('public/jquery-ui-1.12.1/jquery-ui.min.js')?>"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $(".dp").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    maxDate: "0m -1d",
                    dateFormat: "dd-mm-yy"
                }); //End of onclick .datepicker
                
                $(".dpnxt").datepicker({
                    changeMonth: true,
                    changeYear: true,
                    minDate: "1m 1d",
                    dateFormat: "dd-mm-yy"
                }); //End of onclick .datepicker
            });
        </script>
    </head>
    <body class="fixed-nav sticky-footer bg-dark" id="page-top">
        <?php if ($this->session->flashdata("flashMsg")) { ?>
            <script type="text/javascript">
                $.notify("<?=$this->session->flashdata("flashMsg")?>", "success");
            </script>
        <?php } ?>
        <?php $this->load->view('requires/navbar'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">
                <ol class="breadcrumb" style="padding: .5rem; margin-bottom: 1rem">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url('')?>">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">Payments</li>
                    <li style="float: right">
                        <a href="javascript:history.back(-1)" class="btn btn-info" style="margin: 0px; padding: 4px;">
                            <i class="fa fa-chevron-circle-left"></i> Back
                        </a>
                    </li>
                </ol><!-- End of .breadcrumb-item-->
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card frmcard border-primary">
                            <form action="<?=base_url('payments/save')?>" method="post">
                                <div class="card-header">
                                    <i class="fa fa-university"></i> <?=$title?>
                                </div>
                                <div class="card-body">
                                    <input type="hidden" name="payment_id" id="payment_id" value="<?=$payment_id?>" />
                                    <div class="row">
                                        <div class=" col-md-6 form-group">
                                            <label>Customer<span class="text-danger">*</span></label>
                                            <select name="customer_id" class="form-control">
                                                <option value="<?=$customer_id?>" selected="selected"><?=$customer_name?></option>
                                                <?php 
                                                if(isset($customers)) {
                                                    foreach($customers as $custs) { ?>
                                                    <option value="<?=$custs->customer_id?>" >
                                                        <?=$custs->customer_name?>
                                                    </option>
                                                    <?php } //End of foreach  ?>
                                                <?php } else {
                                                    echo "<option value=''>No records found</option>";
                                                } //End of if else ?>
                                            </select>
                                            <?=form_error("customer_id")?>
                                        </div>

                                        <div class="col-md-6 form-group">
                                            <label>Transaction ID<span class="text-danger">*</span></label>
                                            <input type="text" name="transaction_id" value="<?=$transaction_id?>" class="form-control" />
                                            <?=form_error("transaction_id")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label>Payment mode<span class="text-danger">*</span></label>
                                            <select name="payment_mode" id="noq" class="form-control">
                                                <option value="<?=$payment_mode?>" selected="selected"><?=$pMode?></option>
                                                <option value="1">Online</option>
                                                <option value="2">Cash</option>
                                                <option value="3">Cheque</option>
                                            </select>
                                            <?=form_error("payment_mode")?>
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>Payment method<span class="text-danger">*</span></label>
                                            <input type="text" name="payment_method" value="<?=$payment_method?>" class="form-control" />
                                            <?=form_error("payment_method")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                    <div class="row">
                                        <div class="col-md-6 form-group">                                            
                                            <label>Payment amount<span class="text-danger">*</span></label>
                                            <input type="text" name="payment_amount" value="<?=$payment_amount?>" class="form-control" />
                                            <?=form_error("payment_amount")?>
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>Payment date<span class="text-danger">*</span></label>
                                            <input type="text" name="payment_time" value="<?=$payment_time?>" class="form-control dp" />
                                            <?=form_error("payment_time")?>
                                        </div>
                                    </div> <!-- End of .row -->

                                    <div class="row">
                                        <div class="col-md-12 form-group">
                                            <label>Payment note/description</label>
                                            <textarea name="payment_note" class="form-control"><?=$payment_note?></textarea>
                                            <?=form_error("payment_note")?>
                                        </div>
                                    </div> <!-- End of .row -->
                                </div><!--End of .card-body-->
                                
                                <div class="card-footer text-center">
                                    <button type="reset" class="btn btn-danger">
                                        <i class="fa fa-remove"></i> Reset
                                    </button>
                                    <button type="submit" class="btn btn-success">
                                        <i class="fa fa-check"></i> Save
                                    </button>
                                </div><!--End of .card-footer-->
                            </form>
                        </div><!--End of .card-->
                    </div><!--End of .col-md-12-->
                </div><!--End of .row-->
            </div><!--End of container-fluid-->
            <?php $this->load->view('requires/footer'); ?>
            <?php $this->load->view('requires/logoutmodal'); ?>
        </div><!--End of content-wrapper-->
    </body>
</html>