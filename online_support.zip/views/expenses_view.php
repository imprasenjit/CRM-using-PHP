<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Expenses - EODB Support</title>      
        <?php $this->load->view('requires/cssjs'); ?>
        <link rel="stylesheet" href="<?=base_url('public/datatables/css/dataTables.bootstrap4.min.css')?>" />
        <script src="<?=base_url('public/datatables/js/jquery.dataTables.min.js')?>"></script>
        <script src="<?=base_url('public/datatables/js/dataTables.bootstrap4.min.js')?>"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $("#dtbl").DataTable({
                    "order": [[0, 'asc']],
                    "lengthMenu": [[10, 20, 50, 100, 200], [10, 20, 50, 100, 200]]
                });
            });
        </script>
    </head>
    <body class="fixed-nav sticky-footer bg-dark" id="page-top">
        <?php if ($this->session->flashdata("flashMsg")) { ?>
            <script type="text/javascript">
                $.notify("<?=$this->session->flashdata("flashMsg")?>", "success");
            </script>
        <?php } ?>
        <?php $this->load->view('requires/navbar'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">
                <ol class="breadcrumb" style="padding: .5rem; margin-bottom: 1rem">
                    <li class="breadcrumb-item">
                        <a href="<?=base_url('welcome')?>">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">Expenses</li>
                    <li style="float: right">
                        <a href="javascript:history.back(-1)" class="btn btn-info" style="margin: 0px; padding: 4px;">
                            <i class="fa fa-chevron-circle-left"></i> Back
                        </a>
                    </li>
                </ol><!-- End of .breadcrumb-item-->
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card tblcard border-secondary">
                            <div class="card-header">
                                <i class="fa fa-list-alt"></i> Registered expenses list
                                <a href="<?=base_url('expenses/addnew')?>" class="btn btn-primary" style="margin: 0px; padding: 4px; float: right">
                                    <i class="fa fa-plus-circle"></i> Add new expense
                                </a>
                            </div>
                            <div class="card-body card-body-padding table-responsive" style="padding: 1px">
                                <table class="table table-bordered table-responsive" id="dtbl">
                                    <thead>
                                        <tr>
                                            <th>Expense Time</th>
                                            <th>Amount</th>
                                            <th>Expense Title</th>
                                            <th>Customer</th>
                                            <th class="text-center">Operations</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if(isset($results)) {
                                            foreach ($results as $rows) {
                                                $expense_id = $rows->expense_id;
                                                $customer_id = $rows->customer_id;
                                                $cname = ($this->customers_model->get_row($customer_id))?$this->customers_model->get_row($customer_id)->customer_name:"Not found!";
                                                $expense_amount = $rows->expense_amount;
                                                $expense_title  = $rows->expense_title;
                                                $expense_description = $rows->expense_description;
                                                $expense_time = date("d-m-Y h:i A", strtotime($rows->expense_time));
                                                ?>
                                                <tr>
                                                    <td><?=$expense_time?></td>
                                                    <td>Rs. <?=sprintf("%0.2f", $expense_amount)?></td>
                                                    <td><?=$expense_title?></td>
                                                    <td><?=$cname?></td>
                                                    <td class="text-center">
                                                        <a href="<?=base_url('expenses/delete/')?><?=$expense_id?>.htm" class="btn btn-danger del">
                                                            <i class="fa fa-remove"></i>
                                                        </a>
                                                        <a href="<?=base_url('expenses/addnew/')?><?=$expense_id?>.htm" class="btn btn-primary">
                                                            <i class="fa fa-pencil"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php                     
                                            }// End of foreach
                                        }// End of if  
                                        ?>                           
                                    </tbody>
                                </table>
                            </div><!--End of card-body-->
                        </div><!--End of .card-->
                    </div>
                </div><!--End of .row-->
            </div><!--End of container-fluid-->
            <?php $this->load->view('requires/footer'); ?>
            <?php $this->load->view('requires/logoutmodal'); ?>
        </div>
    </body>
</html>