<div class="modal fade" id="supportviewModal" tabindex="-1" role="dialog" aria-labelledby="supportviewModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document" style="max-width: 1000px">         
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="supportviewModalLabel">Ticket details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="supportviewModalBody">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal" aria-label="Close">
                    <i class="fa fa-remove"></i> Close
                </button>
            </div>
        </div>
    </div>
</div>