#!/usr/local/bin/php -q
<?php
$fp = fopen("php://stdin", "r"); 

require_once "mailparser/src/Parser.php";
$Parser = new PhpMimeMailParser\Parser();

$Parser->setStream($fp); 
//$from = $Parser->getHeader('from');  
$addressesFrom = $Parser->getAddresses('from');
$subject = $Parser->getHeader('subject');
$text = $Parser->getMessageBody('text');
$attach_dir = __DIR__.'/attachments/';
$include_inline = true;
$attachments=$Parser->saveAttachments($attach_dir ,$include_inline);

if($attachments){
$upload_file=$attachments[0];
$tmp=explode(".", $upload_file);
$file_extension = strtolower(end($tmp));
$renameFile=sha1(uniqid(rand())).".".$file_extension;
$newfile = __DIR__.'/storage/uploads/'.$renameFile;
if(file_exists($upload_file)){
rename($upload_file,$newfile);
}else{
   $renameFile=""; 
}
}else{
 $renameFile="";   
}



//print_r($attachments);

//$lines = explode(PHP_EOL, trim($text));
$newstr=nl2br($text);
/*
foreach($lines as $line){
	$newstr.=$line."<br>";
}
*/


$name=$addressesFrom[0]['display'];
$from=$addressesFrom[0]['address'];

//For Getting the Ticket 
preg_match_all("/\\[(.*?)\\]/", $subject, $matches); 


//echo $matches[1][0];
ob_start();
require_once('index.php');
ob_end_clean();
$CI = & get_instance();

$CI->load->helper("ticketreply");

$sub=$matches[1][0];

$mysqli = new mysqli("localhost", "eodb_dicc", "Egov@20#AIPL18", "eodb_crm");
if ($mysqli->connect_errno) {
printf("Connect failed: %s\n", $mysqli->connect_error);
exit();
}
$today = date("Y-m-d H:i:s");        
if ($mysqli->query("INSERT INTO emails (email_from,email_body,email_subject,email_time) VALUES ('".$from."','".$newstr."','".$sub."','".$today."')") ===TRUE) {
    reply_ticket($sub,$newstr,$name."  ( ".$from." )",$renameFile);exit();
}
?>